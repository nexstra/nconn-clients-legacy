create view campaign_elems_view as
  select `hpe`.`dist_elem`.`dist_elem_id`                   AS `dist_elem_id`,
         `hpe`.`dist_elem`.`dist_list_id`                   AS `dist_list_id`,
         `hpe`.`dist_elem`.`id`                             AS `id`,
         `hpe`.`dist_elem_item`.`dist_list_def_id`          AS `dist_list_def_id`,
         `hpe`.`dist_elem_item`.`value1`                    AS `entity_name`,
         `hpe`.`dist_elem_item`.`value2`                    AS `entity_type`,
         `hpe`.`dist_elem_item`.`value3`                    AS `contact_name`,
         `hpe`.`dist_elem_item`.`value4`                    AS `av_address1`,
         `hpe`.`dist_elem_item`.`value5`                    AS `av_address2`,
         `hpe`.`dist_elem_item`.`value6`                    AS `av_city`,
         `hpe`.`dist_elem_item`.`value7`                    AS `av_state`,
         `hpe`.`dist_elem_item`.`value8`                    AS `postal_code`,
         `hpe`.`dist_elem_item`.`value9`                    AS `av_country`,
         `hpe`.`dist_elem_item`.`value10`                   AS `email_address_customer`,
         `hpe`.`dist_elem_item`.`value11`                   AS `region`,
         `hpe`.`dist_elem_item`.`value12`                   AS `custom_field1`,
         `hpe`.`dist_elem_item`.`value13`                   AS `all_custom_fields`,
         `hpe`.`dist_elem_item`.`value14`                   AS `record_id`,
         `hpe`.`dist_elem_item`.`value15`                   AS `av_code`,
         `hpe`.`dist_elem_item`.`value16`                   AS `ev_result`,
         `hpe`.`dist_elem_item`.`value17`                   AS `custom_field2`,
         `hpe`.`dist_elem_item`.`value18`                   AS `custom_field3`,
         `hpe`.`dist_elem_item`.`value19`                   AS `custom_field4`,
         `hpe`.`dist_elem_item`.`value20`                   AS `custom_field5`,
         `hpe`.`dist_elem_item`.`value21`                   AS `block_all`,
         `hpe`.`dist_elem_item`.`value22`                   AS `orig_email_address`,
         `hpe`.`campaign_dist_elem`.`campaign_state_status` AS `campaign_state_status`,
         `hpe`.`campaign_dist_elem`.`run_dt`                AS `run_dt`,
         `hpe`.`campaign_dist_elem`.`last_run_dt`           AS `last_run_dt`,
         `hpe`.`campaign_dist_elem`.`last_active_dt`        AS `last_active_dt`,
         `hpe`.`campaign_state`.`name`                      AS `campaign_state`,
         `hpe`.`campaign_dist_elem`.`campaign_dist_elem_id` AS `campaign_dist_elem_id`,
         `hpe`.`campaign`.`name`                            AS `campaign_name`
  from ((((`hpe`.`dist_elem` join `hpe`.`dist_elem_item` on ((`hpe`.`dist_elem`.`dist_elem_id` =
                                                              `hpe`.`dist_elem_item`.`dist_elem_id`))) join `hpe`.`campaign_dist_elem` on ((
    `hpe`.`dist_elem_item`.`dist_elem_id` =
    `hpe`.`campaign_dist_elem`.`dist_elem_id`))) join `hpe`.`campaign_state` on ((
    `hpe`.`campaign_dist_elem`.`campaign_state_id` =
    `hpe`.`campaign_state`.`campaign_state_id`))) join `hpe`.`campaign` on ((`hpe`.`campaign_dist_elem`.`campaign_id` =
                                                                             `hpe`.`campaign`.`campaign_id`)));

