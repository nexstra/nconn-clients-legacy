create view dist_elem_item_dist_list as
  select `hpe`.`dist_elem_item`.`dist_elem_id`     AS `dist_elem_id`,
         `hpe`.`dist_elem_item`.`dist_list_def_id` AS `dist_list_def_id`,
         `hpe`.`dist_elem_item`.`value1`           AS `value1`,
         `hpe`.`dist_elem_item`.`value2`           AS `value2`,
         `hpe`.`dist_elem_item`.`value3`           AS `value3`,
         `hpe`.`dist_elem_item`.`value4`           AS `value4`,
         `hpe`.`dist_elem_item`.`value5`           AS `value5`,
         `hpe`.`dist_elem_item`.`value6`           AS `value6`,
         `hpe`.`dist_elem_item`.`value7`           AS `value7`,
         `hpe`.`dist_elem_item`.`value8`           AS `value8`,
         `hpe`.`dist_elem_item`.`value9`           AS `value9`,
         `hpe`.`dist_elem_item`.`value10`          AS `value10`,
         `hpe`.`dist_elem_item`.`value11`          AS `value11`,
         `hpe`.`dist_elem_item`.`value12`          AS `value12`,
         `hpe`.`dist_elem_item`.`value13`          AS `value13`,
         `hpe`.`dist_elem_item`.`value14`          AS `value14`,
         `hpe`.`dist_elem_item`.`value15`          AS `value15`,
         `hpe`.`dist_elem_item`.`value16`          AS `value16`,
         `hpe`.`dist_elem_item`.`value17`          AS `value17`,
         `hpe`.`dist_elem_item`.`value18`          AS `value18`,
         `hpe`.`dist_elem_item`.`value19`          AS `value19`,
         `hpe`.`dist_elem_item`.`value20`          AS `value20`,
         `hpe`.`dist_elem_item`.`value21`          AS `value21`,
         `hpe`.`dist_elem_item`.`value22`          AS `value22`,
         `hpe`.`dist_elem`.`dist_list_id`          AS `dist_list_id`
  from (`hpe`.`dist_elem_item` join `hpe`.`dist_elem` on ((`hpe`.`dist_elem_item`.`dist_elem_id` =
                                                           `hpe`.`dist_elem`.`dist_elem_id`)));

