create view connector_log_view as
  select `hpe`.`connector_log`.`connector_log_id`                                                               AS `log_id`,
         `hpe`.`connector_log`.`connector_id`                                                                   AS `id`,
         `hpe`.`connector_log`.`start_dt`                                                                       AS `start_dt`,
         `hpe`.`connector_log`.`end_dt`                                                                         AS `end_dt`,
         `hpe`.`connector_log`.`log_data`                                                                       AS `log_data`,
         cast(nullif(trim(trailing ' elements' from substring_index(substr(substr(`hpe`.`connector_log`.`log_data`,
                                                                                  locate('Loaded: ', `hpe`.`connector_log`.`log_data`)),
                                                                           9), '\n', 1)), '') as
              unsigned)                                                                                         AS `loaded`,
         nullif(substring_index(substr(substr(`hpe`.`connector_log`.`log_data`,
                                              locate('loading records from file: ', `hpe`.`connector_log`.`log_data`)),
                                       28), '\n', 1),
                '')                                                                                             AS `file`,
         nullif(trim(trailing ' id' from substring_index(substr(substr(`hpe`.`connector_log`.`log_data`,
                                                                       locate('Attaching distribution list: ', `hpe`.`connector_log`.`log_data`)),
                                                                29), ':', 1)),
                '')                                                                                             AS `dist_list`,
         nullif(trim(trailing ' campaign_id' from substring_index(substr(substr(`hpe`.`connector_log`.`log_data`,
                                                                                locate('to Campaign: ', `hpe`.`connector_log`.`log_data`)),
                                                                         13), ':', 1)),
                '')                                                                                             AS `campaign`,
         if((locate('Loaded: ', `hpe`.`connector_log`.`log_data`) > 0), `hpe`.`connector_log`.`start_dt`,
            NULL)                                                                                               AS `loaded_dt`
  from `hpe`.`connector_log`;

