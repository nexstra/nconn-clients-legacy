create view campaign_message_event_view as
  select `hpe`.`dist_message_event`.`dist_message_id` AS `dist_message_id`,
         `hpe`.`dist_method_event`.`name`             AS `event`,
         `hpe`.`dist_message_event`.`event_dt`        AS `event_dt`,
         `hpe`.`dist_message_event`.`detail`          AS `detail`
  from (`hpe`.`dist_message_event` join `hpe`.`dist_method_event` on ((`hpe`.`dist_message_event`.`dist_method_event_id`
                                                                       =
                                                                       `hpe`.`dist_method_event`.`dist_method_event_id`)));

