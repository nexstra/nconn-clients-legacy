create view campaign_script as select `hpe`.`campaign`.`campaign_id`  AS `campaign_id`,
                                      `hpe`.`campaign`.`global_rules` AS `script`
                               from `hpe`.`campaign`
                               union all select `hpe`.`campaign`.`campaign_id`  AS `campaign_id`,
                                                `hpe`.`campaign`.`common_rules` AS `common_rules`
                                         from `hpe`.`campaign`
                               union all select `hpe`.`campaign_state`.`campaign_id` AS `campaign_id`,
                                                `hpe`.`campaign_state`.`rule`        AS `rule`
                                         from `hpe`.`campaign_state`;

