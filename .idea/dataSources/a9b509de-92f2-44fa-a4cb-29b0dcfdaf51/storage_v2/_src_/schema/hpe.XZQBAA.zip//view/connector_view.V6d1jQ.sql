create view connector_view as
  select `hpe`.`connectors`.`connector_id`                   AS `id`,
         `hpe`.`client`.`name`                               AS `client_name`,
         `hpe`.`connector_types`.`name`                      AS `type`,
         `hpe`.`connectors`.`name`                           AS `name`,
         `hpe`.`connectors`.`running`                        AS `running`,
         `hpe`.`connectors`.`state`                          AS `state`,
         `hpe`.`connectors`.`run_type`                       AS `run_type`,
         `hpe`.`connectors`.`run_start`                      AS `run_start`,
         `hpe`.`connectors`.`run_every`                      AS `run_every`,
         `hpe`.`connectors`.`run_every_unit`                 AS `run_every_unit`,
         `hpe`.`connectors`.`properties`                     AS `properties`,
         `hpe`.`connectors`.`start_dt`                       AS `start_dt`,
         `hpe`.`connectors`.`end_dt`                         AS `end_dt`,
         `hpe`.`connectors`.`config_data`                    AS `config_data`,
         concat('[', trim(trailing ',' from
                          group_concat(`connector_log_view`.`loaded`, ',', unix_timestamp(`connector_log_view`.`end_dt`)
                                       separator ',')), ']') AS `loaded_history`,
         max(`connector_log_view`.`loaded_dt`)               AS `last_loaded_dt`
  from (((`hpe`.`connectors` join `hpe`.`client` on ((`hpe`.`connectors`.`client_id` =
                                                      `hpe`.`client`.`client_id`))) join `hpe`.`connector_types` on ((
    `hpe`.`connectors`.`connector_type_id` =
    `hpe`.`connector_types`.`connector_type_id`))) left join `hpe`.`connector_log_view` on ((
    `hpe`.`connectors`.`connector_id` = `connector_log_view`.`id`)))
  group by `connector_log_view`.`id`
  order by `connector_log_view`.`log_id` desc;

