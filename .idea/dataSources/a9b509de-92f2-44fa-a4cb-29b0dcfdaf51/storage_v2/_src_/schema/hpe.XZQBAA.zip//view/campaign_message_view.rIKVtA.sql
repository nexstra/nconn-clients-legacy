create view campaign_message_view as
  select `hpe`.`dist_message`.`dist_message_id`       AS `dist_message_id`,
         `hpe`.`dist_message`.`campaign_dist_elem_id` AS `campaign_dist_elem_id`,
         `hpe`.`dist_message`.`create_dt`             AS `create_dt`,
         `hpe`.`dist_message`.`address`               AS `address`,
         `hpe`.`dist_message`.`dist_elem_id`          AS `dist_elem_id`,
         `hpe`.`dist_message`.`tag`                   AS `tag`,
         `hpe`.`dist_message`.`docuri`                AS `docuri`,
         `hpe`.`dist_message`.`rendered_dt`           AS `rendered_dt`,
         `hpe`.`dist_message`.`sent_dt`               AS `sent_dt`,
         `hpe`.`dist_method`.`name`                   AS `dist_method`,
         `hpe`.`campaign`.`name`                      AS `campaign_name`
  from ((`hpe`.`dist_message` join `hpe`.`dist_method` on ((`hpe`.`dist_message`.`dist_method_id` =
                                                            `hpe`.`dist_method`.`dist_method_id`))) join `hpe`.`campaign` on ((
    `hpe`.`dist_message`.`campaign_id` = `hpe`.`campaign`.`campaign_id`)));

