create view connector_view as
  select `ssi-new`.`connectors`.`connector_id`               AS `id`,
         `ssi-new`.`client`.`name`                           AS `client_name`,
         `ssi-new`.`connector_types`.`name`                  AS `type`,
         `ssi-new`.`connectors`.`name`                       AS `name`,
         `ssi-new`.`connectors`.`running`                    AS `running`,
         `ssi-new`.`connectors`.`state`                      AS `state`,
         `ssi-new`.`connectors`.`run_type`                   AS `run_type`,
         `ssi-new`.`connectors`.`run_start`                  AS `run_start`,
         `ssi-new`.`connectors`.`run_every`                  AS `run_every`,
         `ssi-new`.`connectors`.`run_every_unit`             AS `run_every_unit`,
         `ssi-new`.`connectors`.`properties`                 AS `properties`,
         `ssi-new`.`connectors`.`start_dt`                   AS `start_dt`,
         `ssi-new`.`connectors`.`end_dt`                     AS `end_dt`,
         `ssi-new`.`connectors`.`config_data`                AS `config_data`,
         concat('[', trim(trailing ',' from
                          group_concat(`connector_log_view`.`loaded`, ',', unix_timestamp(`connector_log_view`.`end_dt`)
                                       separator ',')), ']') AS `loaded_history`,
         max(`connector_log_view`.`loaded_dt`)               AS `last_loaded_dt`
  from (((`ssi-new`.`connectors` join `ssi-new`.`client` on ((`ssi-new`.`connectors`.`client_id` =
                                                              `ssi-new`.`client`.`client_id`))) join `ssi-new`.`connector_types` on ((
    `ssi-new`.`connectors`.`connector_type_id` =
    `ssi-new`.`connector_types`.`connector_type_id`))) left join `ssi-new`.`connector_log_view` on ((
    `ssi-new`.`connectors`.`connector_id` = `connector_log_view`.`id`)))
  group by `connector_log_view`.`id`
  order by `connector_log_view`.`log_id` desc;

