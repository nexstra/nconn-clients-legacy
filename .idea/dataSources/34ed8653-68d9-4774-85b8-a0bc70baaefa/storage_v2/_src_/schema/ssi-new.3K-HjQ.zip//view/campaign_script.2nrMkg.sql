create view campaign_script as select `ssi-new`.`campaign`.`campaign_id`  AS `campaign_id`,
                                      `ssi-new`.`campaign`.`global_rules` AS `script`
                               from `ssi-new`.`campaign`
                               union all select `ssi-new`.`campaign`.`campaign_id`  AS `campaign_id`,
                                                `ssi-new`.`campaign`.`common_rules` AS `common_rules`
                                         from `ssi-new`.`campaign`
                               union all select `ssi-new`.`campaign_state`.`campaign_id` AS `campaign_id`,
                                                `ssi-new`.`campaign_state`.`rule`        AS `rule`
                                         from `ssi-new`.`campaign_state`;

