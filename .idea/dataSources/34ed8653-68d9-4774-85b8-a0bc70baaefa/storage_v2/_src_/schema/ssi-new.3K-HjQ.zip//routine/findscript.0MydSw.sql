create procedure findscript(IN str text)
  BEGIN
   
   select campaign_id ,SUBSTRING( script FROM  (INSTR( script , str  COLLATE utf8_unicode_ci ) -10 ) FOR 100 ) as script  from campaign_script where INSTR( script , str  COLLATE utf8_unicode_ci);
END;

