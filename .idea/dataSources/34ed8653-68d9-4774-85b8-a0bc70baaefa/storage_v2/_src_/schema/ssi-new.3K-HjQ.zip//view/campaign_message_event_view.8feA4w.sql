create view campaign_message_event_view as
  select `ssi-new`.`dist_message_event`.`dist_message_id` AS `dist_message_id`,
         `ssi-new`.`dist_method_event`.`name`             AS `event`,
         `ssi-new`.`dist_message_event`.`event_dt`        AS `event_dt`,
         `ssi-new`.`dist_message_event`.`detail`          AS `detail`
  from (`ssi-new`.`dist_message_event` join `ssi-new`.`dist_method_event` on ((
    `ssi-new`.`dist_message_event`.`dist_method_event_id` = `ssi-new`.`dist_method_event`.`dist_method_event_id`)));

