create view campaign_message_view as
  select `ssi-new`.`dist_message`.`dist_message_id`       AS `dist_message_id`,
         `ssi-new`.`dist_message`.`campaign_dist_elem_id` AS `campaign_dist_elem_id`,
         `ssi-new`.`dist_message`.`create_dt`             AS `create_dt`,
         `ssi-new`.`dist_message`.`address`               AS `address`,
         `ssi-new`.`dist_message`.`dist_elem_id`          AS `dist_elem_id`,
         `ssi-new`.`dist_message`.`tag`                   AS `tag`,
         `ssi-new`.`dist_message`.`docuri`                AS `docuri`,
         `ssi-new`.`dist_message`.`rendered_dt`           AS `rendered_dt`,
         `ssi-new`.`dist_message`.`sent_dt`               AS `sent_dt`,
         `ssi-new`.`dist_method`.`name`                   AS `dist_method`,
         `ssi-new`.`campaign`.`name`                      AS `campaign_name`,
         `ssi-new`.`client`.`name`                        AS `client_name`
  from (((`ssi-new`.`dist_message` join `ssi-new`.`dist_method` on ((`ssi-new`.`dist_message`.`dist_method_id` =
                                                                     `ssi-new`.`dist_method`.`dist_method_id`))) join `ssi-new`.`campaign` on ((
    `ssi-new`.`dist_message`.`campaign_id` = `ssi-new`.`campaign`.`campaign_id`))) join `ssi-new`.`client` on ((
    `ssi-new`.`campaign`.`client_id` = `ssi-new`.`client`.`client_id`)));

