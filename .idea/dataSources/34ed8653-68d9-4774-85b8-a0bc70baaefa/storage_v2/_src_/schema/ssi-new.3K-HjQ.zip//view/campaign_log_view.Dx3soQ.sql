create view campaign_log_view as
  select `ssi-new`.`connector_log`.`connector_log_id` AS `log_id`,
         `ssi-new`.`connector_log`.`connector_id`     AS `id`,
         `ssi-new`.`connector_log`.`start_dt`         AS `start_dt`,
         `ssi-new`.`connector_log`.`end_dt`           AS `end_dt`,
         `ssi-new`.`connector_log`.`log_data`         AS `log_data`
  from `ssi-new`.`connector_log`;

