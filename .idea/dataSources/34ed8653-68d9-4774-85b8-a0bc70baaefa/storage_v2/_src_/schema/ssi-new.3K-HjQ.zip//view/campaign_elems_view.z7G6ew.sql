create view campaign_elems_view as
  select `ssi-new`.`dist_elem`.`dist_elem_id`                   AS `dist_elem_id`,
         `ssi-new`.`dist_elem`.`dist_list_id`                   AS `dist_list_id`,
         `ssi-new`.`dist_elem`.`id`                             AS `id`,
         `ssi-new`.`dist_elem_item`.`dist_list_def_id`          AS `dist_list_def_id`,
         `ssi-new`.`dist_elem_item`.`value1`                    AS `entity_name`,
         `ssi-new`.`dist_elem_item`.`value2`                    AS `entity_type`,
         `ssi-new`.`dist_elem_item`.`value3`                    AS `contact_name`,
         `ssi-new`.`dist_elem_item`.`value4`                    AS `av_address1`,
         `ssi-new`.`dist_elem_item`.`value5`                    AS `av_address2`,
         `ssi-new`.`dist_elem_item`.`value6`                    AS `av_city`,
         `ssi-new`.`dist_elem_item`.`value7`                    AS `av_state`,
         `ssi-new`.`dist_elem_item`.`value8`                    AS `postal_code`,
         `ssi-new`.`dist_elem_item`.`value9`                    AS `av_country`,
         `ssi-new`.`dist_elem_item`.`value10`                   AS `email_address_customer`,
         `ssi-new`.`dist_elem_item`.`value11`                   AS `region`,
         `ssi-new`.`dist_elem_item`.`value12`                   AS `custom_field1`,
         `ssi-new`.`dist_elem_item`.`value13`                   AS `all_custom_fields`,
         `ssi-new`.`dist_elem_item`.`value14`                   AS `record_id`,
         `ssi-new`.`dist_elem_item`.`value15`                   AS `av_code`,
         `ssi-new`.`dist_elem_item`.`value16`                   AS `ev_result`,
         `ssi-new`.`dist_elem_item`.`value17`                   AS `custom_field2`,
         `ssi-new`.`dist_elem_item`.`value18`                   AS `custom_field3`,
         `ssi-new`.`dist_elem_item`.`value19`                   AS `custom_field4`,
         `ssi-new`.`dist_elem_item`.`value20`                   AS `custom_field5`,
         `ssi-new`.`dist_elem_item`.`value21`                   AS `block_all`,
         `ssi-new`.`dist_elem_item`.`value22`                   AS `orig_email_address`,
         `ssi-new`.`campaign_dist_elem`.`campaign_state_status` AS `campaign_state_status`,
         `ssi-new`.`campaign_dist_elem`.`run_dt`                AS `run_dt`,
         `ssi-new`.`campaign_dist_elem`.`last_run_dt`           AS `last_run_dt`,
         `ssi-new`.`campaign_dist_elem`.`last_active_dt`        AS `last_active_dt`,
         `ssi-new`.`campaign_state`.`name`                      AS `campaign_state`,
         `ssi-new`.`campaign_dist_elem`.`campaign_dist_elem_id` AS `campaign_dist_elem_id`,
         `ssi-new`.`campaign`.`name`                            AS `campaign_name`
  from ((((`ssi-new`.`dist_elem` join `ssi-new`.`dist_elem_item` on ((`ssi-new`.`dist_elem`.`dist_elem_id` =
                                                                      `ssi-new`.`dist_elem_item`.`dist_elem_id`))) join `ssi-new`.`campaign_dist_elem` on ((
    `ssi-new`.`dist_elem_item`.`dist_elem_id` =
    `ssi-new`.`campaign_dist_elem`.`dist_elem_id`))) join `ssi-new`.`campaign_state` on ((
    `ssi-new`.`campaign_dist_elem`.`campaign_state_id` =
    `ssi-new`.`campaign_state`.`campaign_state_id`))) join `ssi-new`.`campaign` on ((
    `ssi-new`.`campaign_dist_elem`.`campaign_id` = `ssi-new`.`campaign`.`campaign_id`)));

