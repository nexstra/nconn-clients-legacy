create view connector_log_view as
  select `ssi-new`.`connector_log`.`connector_log_id`                                                           AS `log_id`,
         `ssi-new`.`connector_log`.`connector_id`                                                               AS `id`,
         `ssi-new`.`connector_log`.`start_dt`                                                                   AS `start_dt`,
         `ssi-new`.`connector_log`.`end_dt`                                                                     AS `end_dt`,
         `ssi-new`.`connector_log`.`log_data`                                                                   AS `log_data`,
         cast(nullif(trim(trailing ' elements' from substring_index(substr(substr(`ssi-new`.`connector_log`.`log_data`,
                                                                                  locate('Loaded: ', `ssi-new`.`connector_log`.`log_data`)),
                                                                           9), '\n', 1)), '') as
              unsigned)                                                                                         AS `loaded`,
         nullif(substring_index(substr(substr(`ssi-new`.`connector_log`.`log_data`,
                                              locate('loading records from file: ',
                                                     `ssi-new`.`connector_log`.`log_data`)), 28), '\n', 1),
                '')                                                                                             AS `file`,
         nullif(trim(trailing ' id' from substring_index(substr(substr(`ssi-new`.`connector_log`.`log_data`,
                                                                       locate('Attaching distribution list: ',
                                                                              `ssi-new`.`connector_log`.`log_data`)),
                                                                29), ':', 1)),
                '')                                                                                             AS `dist_list`,
         nullif(trim(trailing ' campaign_id' from substring_index(substr(substr(`ssi-new`.`connector_log`.`log_data`,
                                                                                locate('to Campaign: ', `ssi-new`.`connector_log`.`log_data`)),
                                                                         13), ':', 1)),
                '')                                                                                             AS `campaign`,
         if((locate('Loaded: ', `ssi-new`.`connector_log`.`log_data`) > 0), `ssi-new`.`connector_log`.`start_dt`,
            NULL)                                                                                               AS `loaded_dt`
  from `ssi-new`.`connector_log`;

