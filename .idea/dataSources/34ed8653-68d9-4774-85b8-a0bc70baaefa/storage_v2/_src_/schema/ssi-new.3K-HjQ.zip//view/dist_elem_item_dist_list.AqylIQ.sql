create view dist_elem_item_dist_list as
  select `ssi-new`.`dist_elem_item`.`dist_elem_id`     AS `dist_elem_id`,
         `ssi-new`.`dist_elem_item`.`dist_list_def_id` AS `dist_list_def_id`,
         `ssi-new`.`dist_elem_item`.`value1`           AS `value1`,
         `ssi-new`.`dist_elem_item`.`value2`           AS `value2`,
         `ssi-new`.`dist_elem_item`.`value3`           AS `value3`,
         `ssi-new`.`dist_elem_item`.`value4`           AS `value4`,
         `ssi-new`.`dist_elem_item`.`value5`           AS `value5`,
         `ssi-new`.`dist_elem_item`.`value6`           AS `value6`,
         `ssi-new`.`dist_elem_item`.`value7`           AS `value7`,
         `ssi-new`.`dist_elem_item`.`value8`           AS `value8`,
         `ssi-new`.`dist_elem_item`.`value9`           AS `value9`,
         `ssi-new`.`dist_elem_item`.`value10`          AS `value10`,
         `ssi-new`.`dist_elem_item`.`value11`          AS `value11`,
         `ssi-new`.`dist_elem_item`.`value12`          AS `value12`,
         `ssi-new`.`dist_elem_item`.`value13`          AS `value13`,
         `ssi-new`.`dist_elem_item`.`value14`          AS `value14`,
         `ssi-new`.`dist_elem_item`.`value15`          AS `value15`,
         `ssi-new`.`dist_elem_item`.`value16`          AS `value16`,
         `ssi-new`.`dist_elem_item`.`value17`          AS `value17`,
         `ssi-new`.`dist_elem_item`.`value18`          AS `value18`,
         `ssi-new`.`dist_elem_item`.`value19`          AS `value19`,
         `ssi-new`.`dist_elem_item`.`value20`          AS `value20`,
         `ssi-new`.`dist_elem_item`.`value21`          AS `value21`,
         `ssi-new`.`dist_elem_item`.`value22`          AS `value22`,
         `ssi-new`.`dist_elem`.`dist_list_id`          AS `dist_list_id`
  from (`ssi-new`.`dist_elem_item` join `ssi-new`.`dist_elem` on ((`ssi-new`.`dist_elem_item`.`dist_elem_id` =
                                                                   `ssi-new`.`dist_elem`.`dist_elem_id`)));

